<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>F1 Manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>F1 Manager</h1>
    </header>
    <?php 

    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    include 'DBmanager.php';
    ///en vez de usar isset, usar empty() para cada campo
    //poñer try catch en cada invocación e en cada DBManager metodo
    //cambiar o close connection 
    //revisar CSS
    echo '<nav class="navElement">
    <a class="topNav" href="index.php?load=drivers">Drivers</a>
    <a class="topNav" href="index.php?load=teams">Teams</a>
    <a class="topNav" href="index.php?load=cars">Cars</a></nav><br><br>';

    if($_SERVER["REQUEST_METHOD"] == "GET" ||$_SERVER["REQUEST_METHOD"] == "POST" ){
        if(isset($_GET["load"])){
            if($_GET["load"] == "drivers"){

                include 'driverManager.php';

            }elseif($_GET["load"] == "teams"){

                include 'teamManager.php';

            }elseif($_GET["load"] == "cars"){
                include 'carManager.php';
            }
        }
    }
    ?>
    
</body>
</html>